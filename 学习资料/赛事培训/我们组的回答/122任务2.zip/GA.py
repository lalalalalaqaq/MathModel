def obj_func(p):
    x1, x2, x3, x4, x5 ,x6 = p
    return -(24*(x1+x2+x3)+15*(x4+x5+x6)-20*(x1+x4)-12*(x2+x5)-8*(x3+x6))




constraint_ueq = [
    ##总量
    lambda x: x[0] + x[3] - 500,
    lambda x: x[1] + x[4] - 750,
    lambda x: x[2] + x[5] - 625,

    lambda x: 600 - (x[0] + x[1] + x[2]),
    lambda x: 800 - (x[3] + x[4] + x[5]),

    #产量
    lambda x: 0.5 *(x[0] + x[1] + x[2])  - x[0]      ,
    lambda x: 0.25*(x[0] + x[1] + x[2])  - x[1]      ,
    lambda x:      x[2]  - (x[0] + x[1] + x[2])*0.1  ,

    lambda x:      x[3]  - (x[3] + x[4] + x[5])*0.4  ,
    lambda x:      x[4]  - (x[3] + x[4] + x[5])*0.4  ,
    lambda x: 0.15*(x[3] + x[4] + x[5])  - x[5]      ,
]

from sko.GA import GA

GA = GA(
        func=obj_func,
        n_dim=6, 
        size_pop=100, 
        max_iter=1000, 
        lb=[0   , 0   , 0    , 0   , 0   , 0   ], 
        ub=[1000, 1000, 1000 , 1000, 1000, 1000],
 
        constraint_ueq=constraint_ueq,
        precision=[1,1,1,1,1,1]
        )

best_x, best_y = GA.run()
print(best_x[0])
print(best_x[1])
print(best_x[2])
print(best_x[3])
print(best_x[4])
print(best_x[5])

print(best_y)
